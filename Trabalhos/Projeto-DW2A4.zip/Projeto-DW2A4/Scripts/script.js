// Função para aguardar um tempo em milissegundos antes de prosseguir.
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

